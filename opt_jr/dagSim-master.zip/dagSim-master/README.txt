This code is under Apache licence.
LUA licence is defined as per https://www.lua.org/license.html
